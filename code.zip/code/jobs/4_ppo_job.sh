#!/bin/bash
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/4_ppo_1_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/4_ppo_2_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/4_ppo_3_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/4_ppo_4_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/4_ppo_5_script.R --vanilla;



