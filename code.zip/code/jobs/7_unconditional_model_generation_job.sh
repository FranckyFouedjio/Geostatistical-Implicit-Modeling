#!/bin/bash
python /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/7_unconditional_model_generation_1_script.py;
python /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/7_unconditional_model_generation_2_script.py;
python /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/7_unconditional_model_generation_3_script.py;
python /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/7_unconditional_model_generation_4_script.py;



