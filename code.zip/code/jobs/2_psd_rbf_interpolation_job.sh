#!/bin/bash
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/2_psd_rbf_interpolation_1_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/2_psd_rbf_interpolation_2_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/2_psd_rbf_interpolation_3_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/2_psd_rbf_interpolation_4_script.R --vanilla;
Rscript /media/fouedjio/095e0241-4724-4a1f-84f8-9ddda0df2da9/fouedjio/geostatistical_implicit_modeling/code/scripts/3_psd_rbf_interpolation_script.R --vanilla;



